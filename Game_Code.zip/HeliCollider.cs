﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

/*
 * A class to activate collider if player is in range.
 */
public class HeliCollider : MonoBehaviour
{
    // if player is in range of the collider,
    // a new scene will be displayed.
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            SceneManager.LoadScene("PlayScene");
        }
    }
}
