﻿using UnityEngine;

public class PlayerShooting : MonoBehaviour
{
    // The damage inflicted by each bullet.
    public int damagePerShot = 20;
    // The time between each shot.
    public float timeBetweenBullets = 0.15f;
    // The distance the gun can fire.
    public float range = 100f;

    // A timer to determine when to fire.
    float timer;
    // A ray from the gun end forwards.
    Ray shootRay;
    // A raycast hit to get information about what was hit.
    RaycastHit shootHit;
    // A layer mask so the raycast only hits things on the shootable layer.
    int shootableMask;
    // Reference to the particle system.
    ParticleSystem gunParticles;
    // Reference to the line renderer.
    LineRenderer gunLine;
    // Reference to the audio source.
    AudioSource gunAudio;
    // Reference to the light component.
    Light gunLight;
    // The proportion of the timeBetweenBullets that the effects will display for.
    float effectsDisplayTime = 0.2f;                

    void Awake()
    {
        // Create a layer mask for the Shootable layer.
        shootableMask = LayerMask.GetMask("Shootable");

        // Set up the references.
        gunParticles = GetComponent<ParticleSystem>();
        gunLine = GetComponent<LineRenderer>();
        gunAudio = GetComponent<AudioSource>();
        gunLight = GetComponent<Light>();
    }

    void Update()
    {
        // Add the time since Update was last called to the timer.
        timer += Time.deltaTime;

        // If the Fire1 button is being press and it's time to fire, shoot 
        if (Input.GetButton("Fire1") && timer >= timeBetweenBullets)
        {
            Shoot();
        }

        // If the timer has exceeded the proportion of timeBetweenBullets that the effects should be displayed for, disable the effects
        if (timer >= timeBetweenBullets * effectsDisplayTime)
        {
            DisableEffects();
        }
    }

    public void DisableEffects()
    {
        // Disable the line renderer and the light.
        gunLine.enabled = false;
        gunLight.enabled = false;
    }

    void Shoot()
    {
       // Reset the timer
        timer = 0f;

        // Play the gun shot audioclip.
        gunAudio.Play();

        // Enable the light.
        gunLight.enabled = true;

        // Stop the particles from playing if they were, then start the particles.
        gunParticles.Stop();
        gunParticles.Play();

        // Enable the line renderer and set it's first position to be the end of the gun.
        gunLine.enabled = true;
        gunLine.SetPosition(0, transform.position);

        // Set the shootRay so that it starts at the end of the gun and points forward from the barrel.
        shootRay.origin = transform.position;
        shootRay.direction = transform.forward;

        // Perform the raycast against gameobjects on the shootable layer and if it hits something
        // try and find an EnemyHealth script on the gameobject hit.
        if (Physics.Raycast(shootRay, out shootHit, range, shootableMask))
        {
           
            EnemyHealth enemyHealth = shootHit.collider.GetComponent<EnemyHealth>();

            // If the EnemyHealth component exist, the enemy should take damage.
            if (enemyHealth != null)
            {             
                enemyHealth.TakeDamage(damagePerShot, shootHit.point);
           }

            // Set the second position of the line renderer to the point the raycast hit
            gunLine.SetPosition(1, shootHit.point);
        }
        // If the raycast didn't hit anything on the shootable layer, set the second position of the line renderer to the fullest extent of the gun's range.
        else
        {
            gunLine.SetPosition(1, shootRay.origin + shootRay.direction * range);
        }
    }
}