﻿using UnityEngine;
using UnityEngine.AI;

public class EnemyHealth : MonoBehaviour
{
    // The amount of health the enemy starts the game with.
    public int startingHealth = 100;
    // The current health the enemy has.
    public int currentHealth;
    // The amount added to the player's score when the enemy dies.
    public int scoreValue = 10;
    // The sound to play when the enemy dies.
    public AudioClip deathClip;

    // Reference to the animator.
    Animator anim;
    // Reference to the audio source.
    AudioSource enemyAudio;
    // Reference to the particle system that plays when the enemy is damaged.
    ParticleSystem hitParticles;
    // Reference to the capsule collider.
    CapsuleCollider capsuleCollider;
    // Whether the enemy is dead.
    bool isDead;                                


    private NavMeshAgent navMesh;
    private Transform player;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player").transform;
        navMesh = GetComponent<NavMeshAgent>();
        anim = GetComponent<Animator>();
    }

    void Awake()
    {
        // Setting up the references.
        enemyAudio = GetComponent<AudioSource>();
        hitParticles = GetComponentInChildren<ParticleSystem>();
        capsuleCollider = GetComponent<CapsuleCollider>();

        // Setting the current health when the enemy first spawns.
        currentHealth = startingHealth;
    }

    void Update()
    {
        // if enemy's health is greater than 0 (alive) 
        // and if the player is within the attacking distance of the enemy
        // the enemy animation (Attack) will be invoked.
        // else - the enemy would chase/hunt the player.
        if (currentHealth > 0)
        {
            if (Mathf.Abs(Vector3.Distance(transform.position, player.transform.position)) < 2.0f)
            {
                anim.Play("Attack");
                navMesh.SetDestination(transform.position);
            }
            else
            {
                navMesh.SetDestination(player.position);
            }
        }

       
    }


    public void TakeDamage(int amount, Vector3 hitPoint)
    {
        // If the enemy is dead no need to take damage so exit the function.
        if (isDead)

            return;

       
        // Reduce the current health by the amount of damage sustained.
        currentHealth -= amount;

        // Set the position of the particle system to where the hit was sustained.
        hitParticles.transform.position = hitPoint;

        // And play the particles.
        hitParticles.Play();

        // If the current health is less than or equal to zero the enemy is dead.
        if (currentHealth <= 0)
        {
            Death();
        }
    }


    void Death()
    {
        // The enemy is dead.
        isDead = true;

        // Turn the collider into a trigger so shots can pass through it.
        capsuleCollider.isTrigger = true;

        // Tell the animator that the enemy is dead.
        anim.SetTrigger("Dead");


        // Increase the score by the enemy's score value.
        ScoreManager.score += scoreValue;
        ScoreManagerDeathMode.score += scoreValue;
       

        // After 2 seconds destory the enemy.
        Destroy(gameObject, 1f);

    }


    
}