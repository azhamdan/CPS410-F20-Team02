﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class HealthCollider : MonoBehaviour
{
    // References the player.
    GameObject player;
    // References the player's health
    PlayerHealth playerHealth;
    // References the health gameObject
    GameObject health;


    private void Awake()
    {
        // assigning player reference to the player gameObject tagged "Player"
        player = GameObject.FindGameObjectWithTag("Player");
        // Getting the playerHealth reference from the PlayerHealth script.
        playerHealth = player.GetComponent<PlayerHealth>();

        health = GameObject.FindGameObjectWithTag("Health");

        health.SetActive(true);
    }

    // Collider function, where if it is the player who entered
    // the the collider/isTrigger, the function will be invoked.
    // In other words, the code will excute only if the player is 
    // detected inside the collider.
    // When the player enters the collider's range, their health bar
    // will refill and they will be fully healed.
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            playerHealth.currentHealth = playerHealth.startingHealth;
            playerHealth.healthSlider.value = playerHealth.currentHealth;
            health.SetActive(false);
        }
    }
}