﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class ScoreManagerDeathMode : MonoBehaviour
{

    // The player's score.
    public static int score;
    // Reference to the Text component.
    Text text;                      


    void Awake()
    {
        // Set up the reference.
        text = GetComponent<Text>();
        // Reset the score.
        score = 0;
    }


    void Update()
    {
        // Set the displayed text to be the word "Score" followed by the score value.
        text.text = "Score: " + score;

        // if the player gets a score of 115, the victory page/scene will be diplayerd.
        if (score == 115)
        {
            SceneManager.LoadScene("VictoryScene");
            Cursor.visible = true;

        }

    }


}