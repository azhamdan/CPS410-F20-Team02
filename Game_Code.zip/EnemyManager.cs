﻿
using UnityEngine;

public class EnemyManager : MonoBehaviour
{

    // Refernce to the player's health
    public PlayerHealth playerHealth;
    // Reference to the enemy
    public GameObject enemy;
    // the spawn time of the enemies
    public float spawnTime = 3f;
    // spawn locations for the enemies
    public Transform[] spawnPoints;


    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Spawn", spawnTime, spawnTime);
    }

    /*
     * The spawn function that will spawn enemies at specific locations on the map.
     */
    void Spawn()
    {
        if(playerHealth.currentHealth <= 0f)
        {
            return;
        }

        int spawnPointIndex = Random.Range(0, spawnPoints.Length);

        Instantiate(enemy, spawnPoints[spawnPointIndex].position, spawnPoints[spawnPointIndex].rotation);
    }
}
