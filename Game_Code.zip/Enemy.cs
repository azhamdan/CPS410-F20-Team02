﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{

    private NavMeshAgent navMesh;
    private Transform player;
    private Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player").transform;
        navMesh = GetComponent<NavMeshAgent>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Mathf.Abs(Vector3.Distance(transform.position, player.transform.position)) <2.0f)
        {
            anim.Play("Attack");
            navMesh.SetDestination(transform.position);
        }
        else
        {
            navMesh.SetDestination(player.position);
        }
    }
}
