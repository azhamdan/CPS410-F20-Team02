﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneController : MonoBehaviour
{
    // function to go to certain scenes.
    public void GoToScene(string scene)
    {
        SceneManager.LoadScene(scene);
    }

    // function to exit the game.
    public void ExitGame()
    {
        Application.Quit();
    }

    // function to load saved games.
    public void RestartGame()
    {
        Application.LoadLevel(Application.loadedLevel);
    }
}