﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cutSceneIsland : MonoBehaviour
{

    /*
     * Game objects that present the cameras.
     */
    public GameObject cameraOne;
    public GameObject cameraTwo;
    public GameObject cameraThree;

    // Start is called before the first frame update
    void Start()
    {
        // calling the StartCoroutine() function
        StartCoroutine(PlayCutScene());
    }

    /*
     * IEnumerator is used to pause iterations
     * and to create parallel actions.
     */
    IEnumerator PlayCutScene()
    {
        yield return new WaitForSeconds(5f);
        cameraOne.SetActive(false);
        cameraTwo.SetActive(true);
        yield return new WaitForSeconds(5f);
        cameraTwo.SetActive(false);
        cameraThree.SetActive(true);
    }
}
